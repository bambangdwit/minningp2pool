#!/usr/bin/env python

from p2pool import main

main.run()
